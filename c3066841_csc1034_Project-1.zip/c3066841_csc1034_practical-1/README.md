Portfolio 1 
=========== 
 
This package is build as a part of the CSC1034: Portfolio-1. 
 
Type `python hello_world.py` to see some useful information.

    --scale
This changes the size of the panda from default=1 and change the scale to any numbers and multiply and get the panda to bigger or smaller size.

    --stop-walk

This changes the panda to stop walking by changing the stop_walk=False to stop_walk=True or add stop-walk in terminal

    --speed

This changes the panda walking speed by setting the default=1 and change the speed faster or slower by changing the numbers.

    --camera_angle_back

This changes the panda view from the back by changing the angle degrees to 180. It also stops rotating.


    --zoom_out

This changes the scene bigger by multiplying with zoom_out scale(default=0.5) and also can make the scene zoom in or zoom out by changing the numbers.