#!/usr/bin/env python

from walking_panda. cli import cli

if __name__ == '__main__':
    cli()
