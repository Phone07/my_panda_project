I have some coding experience before.
My first coding experience was with python. Python has become the foundation of my coding.
Python has adaptability, and many resources and functions have given me the ability to handle various tasks successfully. 
I will describe the Python and IDLE tools that I have used in the past in this report and go over how adding new tools will change the way I approach development.
I have used many python tools and I have created tic tac toe, calendar and rock paper and scissors games by using loop and if statement. 
I have never used the Github before.

Python has a lot of advantages than the others in many ways because it is easy to use across different projects.
It gives programmers the option of object-oriented or procedural programming. Python offers a variety of data type options.
Each sub-data type corresponds to one of the five root types: Number, String, List, Tuple, and Dictionary.
Due to Python's versatility, conducting exploratory data analysis is thus made simpler. It can also be used on Linux, Mac Os and Window equally without asking too many adjustments. 

Python has also become popular today. It is especially easier to learn although the ideas of linear algebra or calculus might be quite difficult, they require the most work.
Python can be swiftly implemented, which enables machine learning developers to quickly evaluate a concept.
Because Python is simple to read, any developer who must change the code may quickly implement, copy, or distribute it. 
By removing misunderstandings, errors, and incompatible paradigms, Python improves algorithm interchange, idea sharing, and tool sharing across AI (Artificial Intelligence) and machine learning experts. 

In conclusion, I can use Python to learn how to use coding languages to tackle analytical challenges in the real world. Learning computer science can help me get ready for occupations like software engineer. 
Coding has facilitated improvements in critical fields including research, education, and healthcare. 
Tasks can be automated by programs, improving productivity and easing human labor.
I can offer my talents to resolving societal problems and enhancing people's working and living situations by learning a programming language like Python. 


