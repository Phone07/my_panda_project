import sys
import platform

print("hello")


print( 1, sys.version)
print( 2, platform.python_implementation())
print( 3, sys.executable)

from math import pi, sin, cos

from direct.showbase.ShowBase import ShowBase
from direct.task import Task
from direct.actor.Actor import Actor

class WalkingPanda(ShowBase):
    def __init__(self, no_rotate=False, scale=1, stop_walk=False, speed=1, camera_angle_back=False, zoom_out=1):
        ## And The rest
        ShowBase.__init__(self)
        # Camera angle from the back
        self.camera_angle_back = camera_angle_back
        # Load the environment model.
        self.scene = self.loader.loadModel("models/environment")
        # Reparent the model to render.
        self.scene.reparentTo(self.render)
        # Apply scale and position transforms on the model.
        self.scene.setScale(zoom_out*0.25, zoom_out*0.25, zoom_out*0.25)
        self.scene.setPos(-8, 42, 0)
        import pygame
        pygame.init()
        pygame.mixer.music.load('panda_sound.ogg')
        pygame.mixer.music.play()
            #Add the spinCameraTask procedure to the task manager.
        if no_rotate:  #for no_rotate
            self.taskMgr.add(self.NospinCameraTask, "NoSpinCameraTask")
        else:
            self.taskMgr.add(self.spinCameraTask, "SpinCameraTask")
         #Load and transform the panda actor.
        if stop_walk:
            self.pandaActor = Actor("models/panda-model",
                                    {"stop_walk": "models/panda-stop_walk"})
        else:
            self.pandaActor = Actor("models/panda-model",
                                {"walk": "models/panda-walk4"})
        self.pandaActor.setScale(scale*0.005,scale*0.005,scale*0.005)
        self.pandaActor.reparentTo(self.render)
        # Loop its animation.
        self.pandaActor.loop("walk")
        self.pandaActor.loop("stop_walk")
        self.pandaActor.setPlayRate(speed, "walk") #for walk speed

    # Define a procedure to move the camera.
    def NospinCameraTask(self, task):
        angleDegrees = 0
        angleRadians = angleDegrees * (pi / 180.0)
        self.camera.setPos(20 * sin(angleRadians), -20.0 * cos(angleRadians), 3)
        self.camera.setHpr(angleDegrees, 0, 0)
        return Task.cont
    def spinCameraTask(self, task):  #for no_roate

        angleDegrees = task.time * 6.0
        angleRadians = angleDegrees * (pi / 180.0)
        self.camera.setPos(20 * sin(angleRadians), -20.0 * cos(angleRadians), 3)
        self.camera.setHpr(angleDegrees, 0, 0)
        camera_angle_back = self.camera_angle_back
        if camera_angle_back:
            angleDegrees= 180
        else:
            angleDegrees = task.time * 6.0
        angleRadians = angleDegrees * (pi / 180.0)
        self.camera.setPos(20 * sin(angleRadians), -20.0 * cos(angleRadians), 3)
        self.camera.setHpr(angleDegrees, 0, 0)
        return Task.cont
