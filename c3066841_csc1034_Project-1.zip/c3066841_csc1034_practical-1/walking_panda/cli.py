from . import panda

import argparse


def cli():
    parser = argparse.ArgumentParser(prog="walking_panda")
    parser.add_argument("--no-rotate", help="Suppress Rotation",
                        action="store_true")
    parser.add_argument("--scale",
                        help="Scale factor for the size of the Panda (default= 1)",
                        type=float, default=1)
    parser.add_argument("--stop-walk",
                        help="stop_walk", action="store_true")
    parser.add_argument("--speed",
                        help="setPlayRate speed for panda", type=float,
                        default=1)
    parser.add_argument("--camera-angle-back",
                        help="Back view", action="store_true")
    parser.add_argument("--zoom-out",
                        help="the scale of environment", type=float,
                        default=1)
    args = parser.parse_args()
    walking = panda.WalkingPanda(**vars(args))
    walking.run()

